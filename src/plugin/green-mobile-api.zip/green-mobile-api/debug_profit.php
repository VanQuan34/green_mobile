<?php
require_once('../../../wp-load.php');

global $wpdb;
$table_products = $wpdb->prefix . 'gm_products';
$table_invoices = $wpdb->prefix . 'gm_invoices';
$table_items = $wpdb->prefix . 'gm_invoice_items';

echo "--- Debug Profit Calculation ---\n";

// Kiểm tra số lượng bản ghi
$items_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_items");
echo "Total Invoice Items: $items_count\n";

$inv_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_invoices WHERE id NOT LIKE 'MANUAL-%'");
echo "Total Actual Invoices: $inv_count\n";

// Kiểm tra 5 bản ghi mẫu của items
$samples = $wpdb->get_results("SELECT it.invoice_id, it.product_id, it.price, p.original_price 
                               FROM $table_items it 
                               LEFT JOIN $table_products p ON it.product_id = p.id 
                               LIMIT 5");
echo "Sample Items with Profit data:\n";
foreach ($samples as $s) {
    $profit = $s->price - $s->original_price;
    echo "Inv: {$s->invoice_id}, Prod: {$s->product_id}, Price: {$s->price}, Cost: {$s->original_price}, Profit: $profit\n";
}

// Chạy query gốc
$inv_where = " WHERE id NOT LIKE 'MANUAL-%' ";
$profit_sql = "SELECT SUM(it.price - p.original_price) 
               FROM $table_items it
               JOIN $table_invoices i ON it.invoice_id = i.id
               LEFT JOIN $table_products p ON it.product_id = p.id
               $inv_where";
$total_profit = $wpdb->get_var($profit_sql);
echo "Result of original SQL: " . var_export($total_profit, true) . "\n";

// Thử query thay thế dùng IFNULL
$profit_sql_safe = "SELECT SUM(IFNULL(it.price, 0) - IFNULL(p.original_price, 0)) 
                    FROM $table_items it
                    JOIN $table_invoices i ON it.invoice_id = i.id
                    LEFT JOIN $table_products p ON it.product_id = p.id
                    $inv_where";
$total_profit_safe = $wpdb->get_var($profit_sql_safe);
echo "Result of safe SQL (IFNULL): " . var_export($total_profit_safe, true) . "\n";
